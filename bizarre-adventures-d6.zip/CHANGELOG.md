# Changelog – BAD6 System

## [0.9.0] – 2025-07-06

### Fixes

-V13 breaking button overflow for D6 Roller
-V13 breaking hue shift right click functionality - now has a hotkey (default crtl+h)
-V13 breaking To Be Continued impact shake. Now only lasts .2 seconds, and isn't as violent.

### KNOWN Issues
-Types default to first entry on render. Temporarily fixed by adding a "none" entry. I intend to fix types one at a time.
-Powers do not currently have a description detailing abilities. Temporarily fixed by necessitating using outside sources.
-Descriptions Aren't praticularly readable in general... Temporarily fixed with outside sources.

