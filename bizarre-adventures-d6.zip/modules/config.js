export const BAD6 = {};

BAD6.attributes = {
    Test: "TEST!"
}