It is reccomended to run with Lancer Initiative for better control over combat intitiative.

Changelog.md inside

**Features:**

Actors:

-Customized Sheet

-Simple, Stylized Stat viewing and editing

-Simplified viewing of Burn type stats (Learning, Luck)

-Hit rendering and auto calculation of damage to health

-Simple item implementation

-Direct locations to fill in character information

**Known limitations**

-Doesn't have a direct implementation for Dark Determination

-Changes to the sheet can be resource intensive for lower end devices

-Limited Functionality for especially unique ability/user types


**Some Future Additions:**

Cleaner Sheet Look

Dark Determination Implementation

Full ability types Implementation

Optimization option for lower end devices

Customized Combat
    Combat based on Lancer Initiative
        Alternate options for freedom of choice

Random Character Generator (Would require a resource)

Enter system onto FoundryVTT

Add better item/hit description functionality
    -Currently struggles with longer descriptions

Properly Expand upon Stand and Power types