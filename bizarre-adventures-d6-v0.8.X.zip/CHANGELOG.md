# Changelog – BAD6 System

## [0.8.X] – 2025-07-04
### V13 Transfer

### Added
Foundations for stand, user, and power type functionality.
Over arching changes to the entire sheet for V13
Scalability and optimization within sheets
### Issues
Types default to first entry on render. Temporarily fixed by adding a "none" entry.
Powers do not currently have a description detailing abilities. Temporarily fixed by necessitating using outside sources.
Descriptions Aren't praticularly readable in general... Temporarily fixed with outside sources.

